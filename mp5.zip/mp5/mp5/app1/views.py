from django.shortcuts import render
from .models import Granite
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import ContactMessage
import json

def home(request):
    granites = Granite.objects.all()
    return render(request, 'app1/home.html', {'granites': granites})

def about(request):
    return render(request, 'app1/about.html')

def contact(request):
    return render(request, 'app1/contact.html')

def contact_form_submission(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            name = data.get('name')
            email = data.get('email')
            message = data.get('message')

            if not name or not email or not message:
                return JsonResponse({'error': 'All fields are required'}, status=400)

            # Save to MongoDB
            ContactMessage.objects.create(name=name, email=email, message=message)

            return JsonResponse({'message': 'Form submitted successfully!'}, status=201)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method'}, status=405)
