from django.contrib import admin
from .models import Granite

admin.site.register(Granite)
